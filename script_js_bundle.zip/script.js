/*
  ALL STOCK catalog configuration.
  Replace the support links and payment placeholders before publishing.
  Product quantities below are sample values. Update them to match real service availability.
*/
const TELEGRAM_URL = "https://t.me/YOUR_TELEGRAM_USERNAME";
const WHATSAPP_URL = "https://wa.me/YOUR_WHATSAPP_NUMBER";

const products = [
  { id: "fb-setup", name: "Facebook Page Setup", category: "Facebook", description: "Page creation guidance, profile setup, and basic security checklist.", price: 350, stock: 12 },
  { id: "fb-support", name: "Facebook Page Support", category: "Facebook", description: "Help with page settings, business profile details, and troubleshooting.", price: 250, stock: 8 },
  { id: "ig-setup", name: "Instagram Profile Setup", category: "Instagram", description: "Profile optimization, business profile setup, and privacy guidance.", price: 300, stock: 10 },
  { id: "ig-support", name: "Instagram Support", category: "Instagram", description: "Setup assistance and account security recommendations.", price: 200, stock: 6 },
  { id: "google-help", name: "Google Account Setup Help", category: "Google", description: "Guidance for creating and securing your own Google account.", price: 200, stock: 15 },
  { id: "security-check", name: "Account Security Checkup", category: "Support", description: "Checklist and guidance for recovery options and two-step verification.", price: 150, stock: 20 }
];

const productGrid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");

document.getElementById("telegramLink").href = TELEGRAM_URL;
document.getElementById("whatsappLink").href = WHATSAPP_URL;
document.getElementById("year").textContent = new Date().getFullYear();

function renderProducts() {
  const term = searchInput.value.trim().toLowerCase();
  const category = categoryFilter.value;
  const visible = products.filter(p =>
    (category === "all" || p.category === category) &&
    (p.name.toLowerCase().includes(term) || p.description.toLowerCase().includes(term))
  );
  productGrid.innerHTML = "";
  if (!visible.length) {
    productGrid.innerHTML = '<div class="empty-state">No services match your search.</div>';
    return;
  }
  visible.forEach(product => {
    const card = document.createElement("article");
    card.className = "product-card";
    const stockClass = product.stock <= 5 ? "stock-chip low" : "stock-chip";
    card.innerHTML = `
      <div class="product-top">
        <span class="category-chip">${product.category}</span>
        <span class="${stockClass}">${product.stock > 0 ? "Available" : "Out of stock"}</span>
      </div>
      <h3>${product.name}</h3>
      <p>${product.description}</p>
      <div class="price-row">
        <div class="price">৳${product.price.toLocaleString("en-BD")} <small>/ service</small></div>
        <label class="quantity">Qty <input type="number" min="1" max="${product.stock}" value="1" ${product.stock < 1 ? "disabled" : ""} aria-label="Quantity for ${product.name}"></label>
      </div>
      <div class="quantity">Stock available: <strong>${product.stock} pcs</strong></div>
      <button class="btn btn-primary order-btn" ${product.stock < 1 ? "disabled" : ""}>Order via Support ↗</button>`;
    const qtyInput = card.querySelector("input");
    const orderBtn = card.querySelector("button");
    orderBtn.addEventListener("click", () => {
      const qty = Math.max(1, Math.min(product.stock, Number.parseInt(qtyInput.value || "1", 10)));
      const total = qty * product.price;
      const message = `Hello ALL STOCK, I want to order: ${product.name}. Quantity: ${qty}. Price per service: BDT ${product.price}. Estimated total: BDT ${total}. Please confirm availability and payment instructions.`;
      const telegramShare = `https://t.me/share/url?url=${encodeURIComponent(location.href)}&text=${encodeURIComponent(message)}`;
      window.open(telegramShare, "_blank", "noopener");
    });
    productGrid.appendChild(card);
  });
}
searchInput.addEventListener("input", renderProducts);
categoryFilter.addEventListener("change", renderProducts);

const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");
menuBtn.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuBtn.setAttribute("aria-expanded", "false");
}));
renderProducts();
